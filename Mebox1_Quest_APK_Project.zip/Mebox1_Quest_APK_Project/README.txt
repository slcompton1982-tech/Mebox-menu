Mebox1 Quest APK Project
========================

This is a standalone Android app prototype with a Quest-friendly menu:
- Developer Mode toggle
- Infinite Coins demo toggle
- Research Points demo toggle
- Infinite Nuts demo toggle
- Reset All button

IMPORTANT: These controls are UI/demo toggles only. They do not connect to or modify
Animal Company, its multiplayer sessions, or its currency. This project does not
include an APK binary; build it with Android Studio / Android Gradle Plugin.

Build:
1. Install Android Studio on a computer.
2. Open this folder as a project.
3. Let Gradle sync.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Locate the APK from app/build/outputs/apk/debug/ after a successful build.

Install on Meta Quest:
1. Enable Developer Mode for your headset and connect it to a computer with USB.
2. Use Meta Quest Developer Hub or Android Debug Bridge (ADB) to install the built APK.
3. Accept any USB debugging prompt inside the headset.

The app is a normal standalone Android app and does not inject into Animal Company.
