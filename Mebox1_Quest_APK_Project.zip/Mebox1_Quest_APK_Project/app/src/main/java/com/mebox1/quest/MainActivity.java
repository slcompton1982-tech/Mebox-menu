package com.mebox1.quest;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    private LinearLayout root;
    private TextView status;
    private boolean devMode = false;
    private boolean infiniteCoins = false;
    private boolean infiniteResearch = false;
    private boolean infiniteNuts = false;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        buildUi();
    }

    private GradientDrawable bg(int color, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(22);
        d.setStroke(2, stroke); return d;
    }

    private TextView text(String s, int size, int color) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        return t;
    }

    private void buildUi() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(34, 22, 34, 22);
        root.setBackgroundColor(Color.rgb(10, 14, 18));
        setContentView(root);

        TextView title = text("MEBOX1  /  QUEST MENU", 28, Color.rgb(116, 255, 147));
        title.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(title, new LinearLayout.LayoutParams(-1, 54));

        TextView sub = text("Standalone menu demo • does not modify Animal Company", 14, Color.LTGRAY);
        root.addView(sub, new LinearLayout.LayoutParams(-1, 32));

        addToggle("Developer Mode", "Show developer/demo status", 0);
        addToggle("Infinite Coins", "Demo toggle only — no live-game currency changes", 1);
        addToggle("Research Points", "Demo toggle only — no live-game research changes", 2);
        addToggle("Infinite Nuts", "Demo toggle only — no live-game currency changes", 3);

        status = text("STATUS: Ready • Demo mode", 15, Color.rgb(190, 205, 195));
        status.setPadding(14, 0, 14, 0);
        status.setBackground(bg(Color.rgb(22, 29, 33), Color.rgb(55, 74, 65)));
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, 48);
        sp.topMargin = 10;
        root.addView(status, sp);

        Button reset = new Button(this);
        reset.setText("RESET ALL TO OFF");
        reset.setTextColor(Color.WHITE);
        reset.setBackground(bg(Color.rgb(38, 48, 52), Color.rgb(116, 255, 147)));
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, 54);
        rp.topMargin = 12;
        root.addView(reset, rp);
        reset.setOnClickListener(v -> {
            devMode = infiniteCoins = infiniteResearch = infiniteNuts = false;
            buildUi();
        });

        TextView footer = text("Mebox1 • Quest-friendly touchscreen layout • Prototype", 12, Color.GRAY);
        footer.setGravity(Gravity.CENTER);
        root.addView(footer, new LinearLayout.LayoutParams(-1, 28));
    }

    private void addToggle(String name, String detail, int id) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(16, 8, 12, 8);
        row.setBackground(bg(Color.rgb(20, 27, 31), Color.rgb(53, 74, 63)));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, 78);
        p.topMargin = 9;
        root.addView(row, p);

        LinearLayout labels = new LinearLayout(this);
        labels.setOrientation(LinearLayout.VERTICAL);
        TextView heading = text(name, 18, Color.WHITE);
        heading.setTypeface(Typeface.DEFAULT_BOLD);
        TextView caption = text(detail, 11, Color.LTGRAY);
        labels.addView(heading);
        labels.addView(caption);
        row.addView(labels, new LinearLayout.LayoutParams(0, -2, 1));

        Switch sw = new Switch(this);
        sw.setText("ON");
        sw.setTextColor(Color.rgb(116, 255, 147));
        sw.setChecked(getValue(id));
        row.addView(sw);
        sw.setOnCheckedChangeListener((button, checked) -> {
            setValue(id, checked);
            if (status != null) status.setText("STATUS: " + name + (checked ? " enabled" : " disabled") + " • Demo only");
        });
    }

    private boolean getValue(int id) {
        switch(id) {
            case 0: return devMode;
            case 1: return infiniteCoins;
            case 2: return infiniteResearch;
            default: return infiniteNuts;
        }
    }
    private void setValue(int id, boolean v) {
        switch(id) {
            case 0: devMode = v; break;
            case 1: infiniteCoins = v; break;
            case 2: infiniteResearch = v; break;
            default: infiniteNuts = v;
        }
    }
}
